#ifndef __ps2_keyboard
#define __ps2_keyboard

	extern int read_PS2_data_ASM(char *data);

#endif



