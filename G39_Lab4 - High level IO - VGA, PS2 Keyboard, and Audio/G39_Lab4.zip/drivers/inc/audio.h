#ifndef __audio
#define __audio
	
	int write_audio_data_ASM(int arg);
	
#endif