extern int MAX_2(int x, int y);

int main(){
    int a,b,c;
    a = 1;
    b = 2;
    c = MAX_2(a, b);
    return c;
}